import React from 'react';
import Home from './pages/Home';
import './App.css';

function App() {
  return (
    <div className="app">
      <header className="neon-text">
        <h1>PLUGIN BUILDER BY PRO GAMER</h1>
      </header>
      <Home />
    </div>
  );
}

export default App;