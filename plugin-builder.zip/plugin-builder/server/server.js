const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

// API Endpoint
app.post('/generate-plugin', (req, res) => {
  const { pluginName, minecraftVersions } = req.body;
  
  res.json({
    status: 'success',
    downloadLink: `/downloads/${pluginName}.jar`
  });
});

app.listen(5000, () => {
  console.log('Server running on http://localhost:5000');
});